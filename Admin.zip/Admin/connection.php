<?php 

$con=mysqli_connect("localhost","root","","minorproject");
session_start();
?>