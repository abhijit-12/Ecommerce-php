<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
</head>
<body>
<form method="get"action="logindetails.php">
<h5>Login ID</h5><input type="text" name="t1">
<h5>Password</h5><input type="text" name="t2"><br><br>

<button type="submit">Login</button>
</form>
</body>
</html>
